import UIKit
import Foundation
let operators = 1
let number1 = 4
let number2 = 8
let multiply: (Int, Int) -> Int = {(num1, num2) in return num1 * num2}
let divide: (Float, Float) -> Float = {(num, den) in return num / den}

    switch operators {
    case 0:
        print(multiply(number1, number2))
    case 1:
        print(divide(Float(number1), Float(number2)))
    default:
        print("Chose a number between 0 and 1")
}

var fullSyntax: Array<Int> = []
var sorthandSyntax : [Int] = []
var inferredSyntax = [1,2,3,4]
var tenZeros = Array(repeating: 0, count: 10)
var error = 0
var numbers = [ 5, 10 , 15]
let first  = numbers[0]
numbers.append(0)
numbers[3] = 20

numbers.count
numbers.contains(10)
print("Elimina el ultimo nombre de la lista \(numbers.popLast()!) ")
/*
var fruits: Set<String> = ["Apple","Orange","Tomato"]
var vegetables: Set = ["Carrot", "Potato", "Tomato"]
fruits.insert("Grapes")
vegetables.remove("Potato")

let healthyFood = fruits.union(vegetables)
healthyFood.count
fruits.isEmpty

var fruits = [String: UInt]()
var vegetables: [String: UInt] = [:]

fruits["manzana"] = 5
vegetables["broccoli"] = 2
let fruitName = fruits.keys
let vegetablesCount = vegetables.values
//
for number in numbers {
    print(number * 2)
}


var fruits: [String: Int]

for (key, value) in fruits{
    print("\(key) \(value)")
}
*/
enum Tabs: String, CaseIterable {
    case home
    case porfile
    case settings
}

let mainTab = Tabs.home
var currentTab: Tabs = .porfile


enum Frutas: String{
    case platano = "Platano"
    case manzana = "Manzana"
    case melon = "Melon"
    case fresas = "Fresas con crema"
}
var frutaFavorita = Frutas.fresas
print("Mi fruta favorita son \(frutaFavorita.rawValue)")

var alumnos: [String: String] = [
    "A01638915": "Bernardo Santiago",
    "A01638911": "Jose Pablo",
    "A01638980": "LCMP",
    "A01639510": "Mateo Chavez"
]
print(alumnos.keys)
print(alumnos.values)
print(alumnos)
for (matricula, nombre) in alumnos {
    print(matricula, nombre)
}
